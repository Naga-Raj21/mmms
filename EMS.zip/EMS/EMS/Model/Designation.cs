﻿namespace EMS.Model
{
    public class Designation
    {
        public int id { get; set; }
        public string DesignationName { get; set; }
        public string Department { get; set; }
    }
}
