﻿namespace EMS.Model
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public int PhoneNumber { get; set; }
        public string MailID { get; set; }
        public string Address { get; set; }
    }
}
