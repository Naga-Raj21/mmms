﻿using MessagePack;
using Microsoft.EntityFrameworkCore;

namespace EMS.Model
{
    public class WorkingHour
    {
       
        public int ID { get; set; }
        public string CompanyWorkingHours { get; set; }
        public string EmployeesWorkingHours { get; set; }
    }
}
