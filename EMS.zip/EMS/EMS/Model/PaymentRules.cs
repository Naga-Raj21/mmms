﻿namespace EMS.Model
{
    public class PaymentRules
    {
        public int ID { get; set; }
        public string CompanyPaymentRules { get; set; }
    }
}
