﻿namespace EMS.Model
{
    public class Leave
    {
        public int ID { get; set; }
        public string LeaveReason { get; set; }
        public DateTime LeaveFrom { get; set; }
        public DateTime LeaveTo { get; set; }
    }
}
