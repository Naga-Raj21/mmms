﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EMS.Data;
using EMS.Model;

namespace EMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WorkingHourController : ControllerBase
    {
        private readonly EmployeeContext _context;

        public WorkingHourController(EmployeeContext context)
        {
            _context = context;
        }

        // GET: api/WorkingHour
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WorkingHour>>> GetWorkingHour()
        {
            return await _context.WorkingHour.ToListAsync();
        }

        // GET: api/WorkingHour/5
        [HttpGet("{id}")]
        public async Task<ActionResult<WorkingHour>> GetWorkingHour(int id)
        {
            var workingHour = await _context.WorkingHour.FindAsync(id);

            if (workingHour == null)
            {
                return NotFound();
            }

            return workingHour;
        }

        // PUT: api/WorkingHour/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutWorkingHour(int id, WorkingHour workingHour)
        {
            if (id != workingHour.ID)
            {
                return BadRequest();
            }

            _context.Entry(workingHour).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WorkingHourExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/WorkingHour
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<WorkingHour>> PostWorkingHour(WorkingHour workingHour)
        {
            _context.WorkingHour.Add(workingHour);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetWorkingHour", new { id = workingHour.ID }, workingHour);
        }

        // DELETE: api/WorkingHour/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteWorkingHour(int id)
        {
            var workingHour = await _context.WorkingHour.FindAsync(id);
            if (workingHour == null)
            {
                return NotFound();
            }

            _context.WorkingHour.Remove(workingHour);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool WorkingHourExists(int id)
        {
            return _context.WorkingHour.Any(e => e.ID == id);
        }
    }
}
