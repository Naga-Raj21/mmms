﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EMS.Data;
using EMS.Model;

namespace EMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentRulesController : ControllerBase
    {
        private readonly EmployeeContext _context;

        public PaymentRulesController(EmployeeContext context)
        {
            _context = context;
        }

        // GET: api/PaymentRules
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PaymentRules>>> GetPaymentRules()
        {
            return await _context.PaymentRules.ToListAsync();
        }

        // GET: api/PaymentRules/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PaymentRules>> GetPaymentRules(int id)
        {
            var paymentRules = await _context.PaymentRules.FindAsync(id);

            if (paymentRules == null)
            {
                return NotFound();
            }

            return paymentRules;
        }

        // PUT: api/PaymentRules/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPaymentRules(int id, PaymentRules paymentRules)
        {
            if (id != paymentRules.ID)
            {
                return BadRequest();
            }

            _context.Entry(paymentRules).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PaymentRulesExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/PaymentRules
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<PaymentRules>> PostPaymentRules(PaymentRules paymentRules)
        {
            _context.PaymentRules.Add(paymentRules);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPaymentRules", new { id = paymentRules.ID }, paymentRules);
        }

        // DELETE: api/PaymentRules/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePaymentRules(int id)
        {
            var paymentRules = await _context.PaymentRules.FindAsync(id);
            if (paymentRules == null)
            {
                return NotFound();
            }

            _context.PaymentRules.Remove(paymentRules);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PaymentRulesExists(int id)
        {
            return _context.PaymentRules.Any(e => e.ID == id);
        }
    }
}
