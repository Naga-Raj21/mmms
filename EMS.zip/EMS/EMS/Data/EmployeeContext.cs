﻿using EMS.Model;
using Microsoft.EntityFrameworkCore;

namespace EMS.Data
{
    public class EmployeeContext : DbContext
    {
        public EmployeeContext(DbContextOptions<EmployeeContext> options)
            : base(options)
        {

        }
        public DbSet<Employee> Employee { get; set; } = null!;
        public DbSet<Designation> Designation { get; set; } = null!;
        public DbSet<WorkingHour> WorkingHour { get; set; } = null!;
        public DbSet<PaymentRules> PaymentRules { get; set; } = null!;
        public DbSet<Leave> Leave { get; set; } = null!;
    }
}
